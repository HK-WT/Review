"""
总结 Agent
职责：综合三路审查结果，生成分级结构化评审报告，并格式化为 GitHub 评论
"""

import json
import requests
from config import ANTHROPIC_API_KEY, CLAUDE_MODEL


SYSTEM_PROMPT = """你是一个专业的 Code Review 总结专家。
你会收到来自多个审查 Agent 的结果，请综合生成一份完整的评审报告。

规则：
- BLOCK 级别：必须修复才能合并，用 🚫 标注
- SUGGEST 级别：强烈建议修复，用 ⚠️ 标注  
- OPTIMIZE 级别：可选优化，用 💡 标注
- 去除重复问题，相同问题只保留一条
- 如果没有 BLOCK 问题，给出通过建议

严格按此 JSON 返回，不输出其他内容：
{
  "verdict": "APPROVE|REQUEST_CHANGES|COMMENT",
  "summary": "一段总体评价",
  "block_count": 数字,
  "suggest_count": 数字,
  "optimize_count": 数字,
  "issues": [
    {
      "level": "BLOCK|SUGGEST|OPTIMIZE",
      "category": "代码规范|Bug检测|安全扫描|一致性校验",
      "file": "文件路径或null",
      "line": 行号或null,
      "message": "问题描述",
      "suggestion": "改进建议"
    }
  ],
  "positive_feedback": "做得好的地方"
}
"""


class SummaryAgent:
    def __init__(self):
        self.headers = {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

    def summarize(self, review_results: dict, parsed_context: dict) -> dict:
        """综合所有审查结果，生成最终报告"""

        content = f"""
解析上下文：
{json.dumps(parsed_context, ensure_ascii=False, indent=2)}

各 Agent 审查结果：
{json.dumps(review_results, ensure_ascii=False, indent=2)}
"""
        payload = {
            "model": CLAUDE_MODEL,
            "max_tokens": 1000,
            "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": content}],
        }

        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=self.headers,
            json=payload,
        )
        resp.raise_for_status()
        raw = resp.json()["content"][0]["text"]

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            return json.loads(raw[start:end])

    def format_github_comment(self, report: dict, parsed_context: dict) -> str:
        """将报告格式化为 Markdown GitHub 评论"""

        verdict_map = {
            "APPROVE": "✅ 审查通过",
            "REQUEST_CHANGES": "❌ 需要修改",
            "COMMENT": "💬 有建议",
        }
        verdict_label = verdict_map.get(report.get("verdict", "COMMENT"), "💬 有建议")

        lines = [
            f"## 🤖 AI Code Review — {verdict_label}",
            "",
            f"> {report.get('summary', '')}",
            "",
            f"| 🚫 必须修复 | ⚠️ 建议修复 | 💡 可选优化 |",
            f"|:-----------:|:-----------:|:-----------:|",
            f"| {report.get('block_count', 0)} | {report.get('suggest_count', 0)} | {report.get('optimize_count', 0)} |",
            "",
        ]

        issues = report.get("issues", [])

        for level, emoji in [("BLOCK", "🚫"), ("SUGGEST", "⚠️"), ("OPTIMIZE", "💡")]:
            level_issues = [i for i in issues if i.get("level") == level]
            if not level_issues:
                continue

            level_labels = {"BLOCK": "必须修复", "SUGGEST": "建议修复", "OPTIMIZE": "可选优化"}
            lines.append(f"### {emoji} {level_labels[level]}")
            lines.append("")

            for issue in level_issues:
                file_info = f"`{issue['file']}`" if issue.get("file") else ""
                line_info = f" L{issue['line']}" if issue.get("line") else ""
                category = issue.get("category", "")

                lines.append(f"**[{category}]** {file_info}{line_info}")
                lines.append(f"- 问题：{issue.get('message', '')}")
                lines.append(f"- 建议：{issue.get('suggestion', '')}")
                lines.append("")

        if report.get("positive_feedback"):
            lines.append("### 👍 做得好的地方")
            lines.append("")
            lines.append(report["positive_feedback"])
            lines.append("")

        lines.append("---")
        lines.append(
            f"*由 Code Review Agent 自动生成 · 变更复杂度：{parsed_context.get('total_complexity', '未知')}*"
        )

        return "\n".join(lines)
