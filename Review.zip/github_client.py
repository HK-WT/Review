import requests
from config import GITHUB_TOKEN, GITHUB_REPO


class GitHubClient:
    BASE = "https://api.github.com"

    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {GITHUB_TOKEN}",
            "Accept": "application/vnd.github.v3+json",
        }

    def get_pull_request(self, pr_number: int) -> dict:
        """获取 PR 基本信息"""
        url = f"{self.BASE}/repos/{GITHUB_REPO}/pulls/{pr_number}"
        resp = requests.get(url, headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def get_pr_files(self, pr_number: int) -> list[dict]:
        """获取 PR 变更文件列表"""
        url = f"{self.BASE}/repos/{GITHUB_REPO}/pulls/{pr_number}/files"
        resp = requests.get(url, headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def get_pr_diff(self, pr_number: int) -> str:
        """获取完整 Diff 内容"""
        url = f"{self.BASE}/repos/{GITHUB_REPO}/pulls/{pr_number}"
        headers = {**self.headers, "Accept": "application/vnd.github.v3.diff"}
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        return resp.text

    def get_pr_history(self, base_branch: str = "main", limit: int = 10) -> list[dict]:
        """获取历史 PR 用于上下文校验"""
        url = f"{self.BASE}/repos/{GITHUB_REPO}/pulls"
        params = {"state": "closed", "base": base_branch, "per_page": limit}
        resp = requests.get(url, headers=self.headers, params=params)
        resp.raise_for_status()
        return resp.json()

    def post_review_comment(self, pr_number: int, body: str) -> dict:
        """在 PR 发布总体评审评论"""
        url = f"{self.BASE}/repos/{GITHUB_REPO}/pulls/{pr_number}/reviews"
        payload = {"body": body, "event": "COMMENT"}
        resp = requests.post(url, headers=self.headers, json=payload)
        resp.raise_for_status()
        return resp.json()

    def post_inline_comment(
        self,
        pr_number: int,
        commit_id: str,
        path: str,
        line: int,
        body: str,
    ) -> dict:
        """在具体代码行发布行内评论"""
        url = f"{self.BASE}/repos/{GITHUB_REPO}/pulls/{pr_number}/comments"
        payload = {
            "body": body,
            "commit_id": commit_id,
            "path": path,
            "line": line,
            "side": "RIGHT",
        }
        resp = requests.post(url, headers=self.headers, json=payload)
        resp.raise_for_status()
        return resp.json()
