"""
Code Review Agent 主入口
用法：
  python main.py --pr 42
  python main.py --pr 42 --dry-run   # 只打印报告，不发布评论
"""

import argparse
import json
import sys

from config import GITHUB_REPO, SECONDARY_REVIEW_THRESHOLD
from github_client import GitHubClient
from agents import ParserAgent, ReviewAgent, SummaryAgent


def run_review(pr_number: int, dry_run: bool = False):
    print(f"\n{'='*60}")
    print(f"🚀 开始审查 PR #{pr_number}  ({GITHUB_REPO})")
    print(f"{'='*60}\n")

    github = GitHubClient()
    parser = ParserAgent()
    reviewer = ReviewAgent()
    summarizer = SummaryAgent()

    # ── Step 1: 获取 PR 数据 ──────────────────────────────────
    print("📥 [1/4] 获取 PR 数据...")
    pr_info = github.get_pull_request(pr_number)
    files = github.get_pr_files(pr_number)
    diff = github.get_pr_diff(pr_number)
    commit_id = pr_info.get("head", {}).get("sha", "")

    print(f"  标题：{pr_info.get('title')}")
    print(f"  变更文件：{len(files)} 个，Diff 行数：{len(diff.splitlines())}")

    # ── Step 2: 解析 Agent ───────────────────────────────────
    print("\n🔍 [2/4] 解析 Agent 分析中...")
    parsed = parser.parse(pr_info, diff, files)
    print(f"  变更复杂度：{parsed.get('total_complexity')}")
    print(f"  涉及模块：{len(parsed.get('modules', []))} 个")
    print(f"  需二次推理：{parsed.get('requires_secondary_review')}")

    # ── Step 3: 审查 Agent（并行三路）────────────────────────
    print("\n⚙️  [3/4] 审查 Agent 并行执行（规范 + Bug + 安全）...")
    review_results = reviewer.review(diff, parsed)
    total_issues = sum(
        len(v.get("issues", [])) for v in review_results.values()
    )
    print(f"  发现原始问题：{total_issues} 条（含重复）")

    # ── Step 4: 总结 Agent ──────────────────────────────────
    print("\n📝 [4/4] 总结 Agent 生成报告...")
    report = summarizer.summarize(review_results, parsed)
    comment_body = summarizer.format_github_comment(report, parsed)

    print(f"\n{'─'*60}")
    print("📊 审查结果：")
    print(f"  判决：{report.get('verdict')}")
    print(f"  🚫 必须修复：{report.get('block_count', 0)}")
    print(f"  ⚠️  建议修复：{report.get('suggest_count', 0)}")
    print(f"  💡 可选优化：{report.get('optimize_count', 0)}")
    print(f"{'─'*60}\n")

    if dry_run:
        print("【Dry Run 模式 — 以下为将发布的评论内容】\n")
        print(comment_body)
        print("\n✅ Dry Run 完成，未发布任何评论。")
        return report

    # ── 发布总体评论 ─────────────────────────────────────────
    github.post_review_comment(pr_number, comment_body)
    print("✅ 总体评审评论已发布")

    # ── 发布行内评论（仅 BLOCK 级别）────────────────────────
    inline_count = 0
    for issue in report.get("issues", []):
        if issue.get("level") == "BLOCK" and issue.get("file") and issue.get("line"):
            body = f"🚫 **[{issue.get('category')}]** {issue.get('message')}\n\n> 建议：{issue.get('suggestion')}"
            try:
                github.post_inline_comment(
                    pr_number,
                    commit_id,
                    issue["file"],
                    issue["line"],
                    body,
                )
                inline_count += 1
            except Exception as e:
                print(f"  ⚠️  行内评论发布失败（{issue['file']}:{issue['line']}）: {e}")

    print(f"✅ 行内评论已发布：{inline_count} 条")
    print("\n🎉 审查完成！")
    return report


def main():
    parser = argparse.ArgumentParser(description="AI Code Review Agent")
    parser.add_argument("--pr", type=int, required=True, help="PR 编号")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印报告，不向 GitHub 发布评论",
    )
    args = parser.parse_args()

    try:
        report = run_review(args.pr, dry_run=args.dry_run)
        # 如有 BLOCK 级问题，以非零状态码退出（可用于 CI 阻断）
        if report.get("block_count", 0) > 0:
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n已取消。")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 执行失败：{e}")
        raise


if __name__ == "__main__":
    main()
