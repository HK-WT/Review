"""
解析 Agent
职责：对 PR Diff 进行结构化拆解，识别变更模块与业务上下文
"""

import json
import requests
from config import ANTHROPIC_API_KEY, CLAUDE_MODEL


SYSTEM_PROMPT = """你是一个专业的代码解析专家。
你的任务是分析 GitHub Pull Request 的 Diff 内容，并输出结构化的解析结果。

请严格按照以下 JSON 格式返回，不要输出任何其他内容：
{
  "pr_title": "PR 标题",
  "change_summary": "整体变更的一句话描述",
  "modules": [
    {
      "file": "文件路径",
      "language": "编程语言",
      "change_type": "新增|修改|删除|重构",
      "business_context": "该文件的业务职责描述",
      "added_lines": 数字,
      "removed_lines": 数字,
      "key_changes": ["变更点1", "变更点2"]
    }
  ],
  "total_complexity": "低|中|高",
  "requires_secondary_review": true或false
}"""


class ParserAgent:
    def __init__(self):
        self.headers = {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

    def parse(self, pr_info: dict, diff: str, files: list[dict]) -> dict:
        """
        解析 PR，返回结构化上下文
        """
        user_content = f"""
PR 标题：{pr_info.get('title', '')}
PR 描述：{pr_info.get('body', '（无描述）')}
目标分支：{pr_info.get('base', {}).get('ref', 'main')}
变更文件数：{len(files)}

--- DIFF 内容 ---
{diff[:4000]}
"""
        payload = {
            "model": CLAUDE_MODEL,
            "max_tokens": 1000,
            "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": user_content}],
        }

        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=self.headers,
            json=payload,
        )
        resp.raise_for_status()
        raw = resp.json()["content"][0]["text"]

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # 容错：提取 JSON 块
            start = raw.find("{")
            end = raw.rfind("}") + 1
            return json.loads(raw[start:end])
