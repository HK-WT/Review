"""
审查 Agent
职责：并行执行静态规范检查、Bug 识别、安全漏洞扫描
"""

import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import ANTHROPIC_API_KEY, CLAUDE_MODEL


# ---------- 三路 Agent 的系统提示 ----------

STYLE_PROMPT = """你是代码规范审查专家。
分析给定的代码变更，检查以下方面：
1. 命名规范（变量/函数/类命名是否清晰语义化）
2. 代码风格（缩进、空行、注释规范）
3. 函数复杂度（单函数是否过长、嵌套是否过深）
4. 重复代码（是否有可抽取复用的逻辑）

严格按此 JSON 返回，不输出其他内容：
{"issues": [{"level": "BLOCK|SUGGEST|OPTIMIZE", "file": "文件", "line": 行号或null, "message": "问题描述", "suggestion": "改进建议"}]}
"""

BUG_PROMPT = """你是资深 Bug 猎手。
分析给定的代码变更，重点检查：
1. 空指针/空引用风险
2. 数组越界、边界条件处理
3. 异常未捕获或处理不当
4. 逻辑错误（条件判断、循环终止）
5. 并发/竞态条件（如有多线程场景）

严格按此 JSON 返回，不输出其他内容：
{"issues": [{"level": "BLOCK|SUGGEST|OPTIMIZE", "file": "文件", "line": 行号或null, "message": "问题描述", "suggestion": "修复建议"}]}
"""

SECURITY_PROMPT = """你是应用安全专家。
分析给定的代码变更，检查以下安全风险：
1. SQL 注入、XSS、CSRF
2. 敏感信息硬编码（密钥、密码、Token）
3. 不安全的反序列化
4. 权限校验缺失
5. 第三方依赖已知漏洞（如可识别）

严格按此 JSON 返回，不输出其他内容：
{"issues": [{"level": "BLOCK|SUGGEST|OPTIMIZE", "file": "文件", "line": 行号或null, "message": "问题描述", "suggestion": "修复建议"}]}
"""


class ReviewAgent:
    def __init__(self):
        self.headers = {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

    def _call_claude(self, system: str, diff_chunk: str, label: str) -> dict:
        payload = {
            "model": CLAUDE_MODEL,
            "max_tokens": 1000,
            "system": system,
            "messages": [
                {"role": "user", "content": f"请审查以下代码变更：\n\n{diff_chunk}"}
            ],
        }
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=self.headers,
            json=payload,
        )
        resp.raise_for_status()
        raw = resp.json()["content"][0]["text"]

        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            result = json.loads(raw[start:end])

        result["review_type"] = label
        return result

    def review(self, diff: str, parsed_context: dict) -> dict:
        """
        并行运行三路审查，合并结果
        """
        diff_chunk = diff[:3000]

        tasks = {
            "style": (STYLE_PROMPT, "代码规范"),
            "bug": (BUG_PROMPT, "Bug 检测"),
            "security": (SECURITY_PROMPT, "安全扫描"),
        }

        results = {}
        with ThreadPoolExecutor(max_workers=3) as executor:
            future_map = {
                executor.submit(self._call_claude, prompt, diff_chunk, label): key
                for key, (prompt, label) in tasks.items()
            }
            for future in as_completed(future_map):
                key = future_map[future]
                try:
                    results[key] = future.result()
                except Exception as e:
                    results[key] = {"review_type": key, "issues": [], "error": str(e)}

        # 二次推理：复杂变更做一致性校验
        if parsed_context.get("requires_secondary_review"):
            results["consistency"] = self._secondary_review(diff, parsed_context)

        return results

    def _secondary_review(self, diff: str, context: dict) -> dict:
        """二次推理：结合解析上下文做一致性检查"""
        system = """你是架构一致性审查专家。
结合提供的模块上下文，检查本次变更是否与已有架构规范一致。
重点：接口契约变更、模块职责边界、跨层依赖是否合理。

严格按此 JSON 返回：
{"issues": [{"level": "BLOCK|SUGGEST|OPTIMIZE", "file": "文件", "line": null, "message": "问题", "suggestion": "建议"}]}
"""
        content = f"模块上下文：{json.dumps(context, ensure_ascii=False)}\n\nDiff：\n{diff[:2000]}"
        return self._call_claude(system, content, "一致性校验")
