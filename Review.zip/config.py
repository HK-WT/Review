import os

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# GitHub
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_REPO = os.getenv("GITHUB_REPO", "owner/repo")  # e.g. "myorg/myrepo"

# Review 配置
MAX_DIFF_LINES = 500       # 单次分析最大行数
SECONDARY_REVIEW_THRESHOLD = 50  # 超过此行数触发二次推理
